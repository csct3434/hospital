package reservation.hospital.domain;

public enum SexType {
    MAN, WOMAN
}
