package reservation.hospital.conroller;

public class DoctorController {
}
