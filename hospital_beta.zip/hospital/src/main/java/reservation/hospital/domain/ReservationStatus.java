package reservation.hospital.domain;

public enum ReservationStatus {
    RESERVED, CANCELED, COMPLETED
}
